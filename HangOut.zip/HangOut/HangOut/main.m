//
//  main.m
//  HangOut
//
//  Created by Doug Sheridan on 2/24/14.
//
//

#import <UIKit/UIKit.h>

#import "HangOutAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HangOutAppDelegate class]));
    }
}
